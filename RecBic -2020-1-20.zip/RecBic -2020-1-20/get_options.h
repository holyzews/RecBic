#ifndef _GET_OPTIONS_H
#define _GET_OPTIONS_H

/*getopt.h is part of the GNU C Library.*/
#include <getopt.h>
#include "struct.h"

/* prototypes */
void get_options (int argc, char* argv[]);

#endif
